/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package famiglia;

/**
 *
 * @author HP
 */
public class Persona {
    String nome, cognome;
    int eta;
    String ruolo;
    char sesso;

    public Persona(String nome, String cognome, int eta, String ruolo, char sesso) {
        this.nome = nome;
        this.cognome = cognome;
        this.eta = eta;
        this.ruolo = ruolo;
        this.sesso = sesso;
    }


    public String getNome() {
        return nome;
    }
    
    
}
