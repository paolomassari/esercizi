
package famiglia;

public class Famiglia {
    Persona[] family =null;
    int num;

    public Famiglia(int componenti) {
        family =  new Persona[componenti];
        this.num = componenti;
    }
    
    public int delPersona(String nome ) {
        int i, posizione = -1;
        for ( i = 0; i < num; i++ ) { 
            if ( family[i] != null && family[i].getNome().equals(nome )) {
                family[i] = null; posizione = i;
            }  
        }
        return posizione;
    }
    
    public int addPersona(Persona p) {
        int i, posizione = -1;
        for ( i = 0; i < num ; i++ ) { 
            if ( family[i] == null ) {
                family[i] = p; 
                return i; 
            }  
        }
        return posizione;
    }
    
    public Persona cercaPersona(String nome ) {
        int i;
        Persona persona = null;
        for ( i = 0; i < num; i++ ) { 
            if ( family[i] != null && family[i].getNome().equals(nome ) ) {
                persona = family[i]; 
                return persona;
            }  
        }
        return persona;
    }
    public Persona[] visualizzaTutti() {
        return family;
    } 
}
